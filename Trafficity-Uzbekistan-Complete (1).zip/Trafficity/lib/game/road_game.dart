import 'dart:convert';
import 'dart:math';
import 'dart:ui';
import 'dart:ui' as ui show Image;

import 'package:flame/game.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'building.dart';
import 'deck.dart';
import 'lane_graph.dart';
import 'rail.dart';
import 'rail_draw.dart';
import 'real_roads.dart';
import 'road_network.dart';
import 'signal.dart';
import 'terrain.dart';
import 'traffic_model.dart';
import 'traffic_sim.dart';

enum Tool { pan, straight, curve, signal, roundabout, erase, building, inspect, grid, station }

class RoadPlan {
  RoadPlan(this.a, this.b, this.c, this.pts, this.length, this.cost, this.error);
  final Offset a, b;
  final Offset? c;
  final List<Offset> pts;
  final double length, cost;
  final String? error;
  bool get valid => error == null;
}

/// Bekor qilish / qaytarish uchun tarmoq holati (yo'llar, aylanalar, svetoforlar).
class _EditState {
  _EditState(this.roads, this.roundabouts, this.signals, this.refund,
      [this.rails = const [], this.stations = const []]);
  final List<(List<Offset>, bool, int, int, double)> roads; // pts, oneWay, type, layer, narx
  final List<(List<Offset>, bool, int, int)> rails; // temir yo'l bo'laklari
  final List<Offset> stations;
  final List<Offset> roundabouts;
  final List<(Offset, double, bool)> signals; // tugun joyi, yashil vaqt, adaptiv
  final double refund; // holat qo'llanganda byudjetga qo'shiladigan miqdor
}

class RoadGame extends FlameGame {
  RoadGame({this.seed = 7});

  static const double startBudget = 3000;
  static const double minRoadLength = 40;
  static const double minZoom = 0.12;
  static const double maxZoom = 3.0;
  static const double _simStep = 0.05;

  int seed;
  late Terrain terrain;
  ui.Image? terrainImage;
  final RoadNetwork net = RoadNetwork();
  final RoadNetwork railNet = RoadNetwork(); // temir yo'l tarmog'i (yo'llardan alohida; yo'l ustidan ko'prik bilan o'tadi)
  late final RailSim rail = RailSim(railNet)
    ..onFare = (st, fare) {
      if (!sandbox) budget += fare;
    };
  final RailVis railVis = RailVis();
  double railCoverage = 0; // xizmat zonasidagi uylar ulushi
  final List<Building> buildings = [];
  late LaneGraph graph;
  late TrafficSim sim;

  /// HUD yangilanishi uchun hisoblagich.
  final ValueNotifier<int> hud = ValueNotifier<int>(0);

  bool loading = true;
  String loadStatus = "Yuklanmoqda...";
  String? loadError;
  double budget = startBudget;
  Tool tool = Tool.pan;
  RoadPlan? currentPlan;
  int noAccess = 0; // yo'lga ulanmagan binolar
  int speed = 1; // 0 pauza, 1, 2, 4
  bool heat = false; // tirbandlik xaritasi

  // shahar darajasi va mamnuniyat
  static const int maxLevel = 12;
  static const double levelNeedSeconds = 20;
  int level = 1;
  double satisfaction = 50;
  double levelTimer = 0;
  String satNote = "";
  int _tripsAtLevel = 0;
  double _econTimer = 0;
  int _nextBuildingId = 1;
  Offset cityCenter = const Offset(3200, 3200);

  /// Dunyo o'lchami, markazi va o'yinchi qo'ygan hudud (xarita shahar o'sishi bilan kengayadi).
  double get worldSize => terrain.size;
  Offset get worldCenter => Offset(terrain.size / 2, terrain.size / 2);
  double terrHalf = 1200; // hudud yarim kengligi (markaz atrofida kvadrat)
  static const double terrStart = 1200, terrStep = 300;
  Paragraph? _centerLabel;

  /// Nuqta hudud ichidami ([pad] chetdan masofa).
  bool inTerritory(Offset p, [double pad = 0]) {
    final c = worldCenter;
    return (p.dx - c.dx).abs() <= terrHalf - pad && (p.dy - c.dy).abs() <= terrHalf - pad;
  }
  double get satTarget => min(85.0, 55 + 3.0 * level + (difficulty - 1) * 5);

  // o'yin sozlamalari
  int biome = Terrain.tashkent; // 0 tekislik, 1 daryo deltasi, 2 tog' vodiysi, 3 orollar, 4 Toshkent (haqiqiy xarita)
  int difficulty = 1; // 0 oson, 1 oddiy, 2 qiyin
  bool sandbox = false;
  int roadType = 0; // 0 oddiy, 1 katta yo'l
  int roadLayer = 0; // 0 yer usti, 1 estakada/ko'prik, 2 temir yo'l, 3 yer osti temir yo'l (tunnel)
  bool get railMode => roadLayer >= 2;
  int buildType = 0; // sandbox: 0 uy, 1 do'kon, 2 zavod
  double demand = 1.0; // sandbox: talab ko'paytmasi
  Vehicle? selected;

  // bekor qilish / qaytarish
  final List<_EditState> _undo = [];
  final List<_EditState> _redo = [];
  bool get canUndo => _undo.isNotEmpty;
  bool get canRedo => _redo.isNotEmpty;

  // yo'l to'ri asbobi
  int gridSpacing = 110;
  List<RoadPlan> gridPlans = [];
  String gridInfo = "";

  // ovoz/tebranish, ishlash o'lchovi
  bool soundOn = true;
  bool menuOpen = false; // bosh menyu ochiq: simulyatsiya to'xtaydi
  double fps = 0;
  double simMs = 0;
  double _fpsAcc = 0;
  int _fpsN = 0;

  // ekologiya: zavod ifloslanishi + transport shovqini
  double env = 1.0; // 1 = toza va tinch
  double supply = 1.0; // do'konlar ta'minoti 0..1
  bool colorBlind = false;
  bool showEnv = false;
  final Map<int, double> envExpo = {}; // uy id -> ekologik yuk 0..1

  // koordinata tekshiruvi (debug)
  bool debug = false;
  Offset? _lastTouch;
  Offset? lastGlobal;
  double dpr = 1;
  Size widgetSize = Size.zero;

  // grafiklar (chegaralangan tarix)
  final List<double> histVeh = [];
  final List<double> histSat = [];
  final List<double> histTrip = [];
  final List<double> histCong = [];
  double _histT = 0;
  bool showCharts = false;

  // xarita aylantirish (ikki barmoq bilan burash)
  double rot = 0;
  double _twist = 0;
  bool _rotating = false;
  double _lastAng = 0;
  Offset? _dragScreen; // chizish paytida barmoq joyi (chetga yetganda xarita suriladi)

  // o'rgatuvchi vazifalar (haqiqiy o'yin holatidan aniqlanadi)
  bool tutorial = true;
  int tutStep = 0;
  bool _heatSeen = false;
  Offset _camStart = Offset.zero;
  double _zoomStart = 1;
  static const tutorialTexts = [
    "Kamerani suring, kattalashtiring yoki buring (2 barmoq)",
    "«To'g'ri» asbobi bilan birinchi yo'lni chizing",
    "Barcha binolarni yo'lga ulang",
    "Mashinalar yurishini kuzating (kamida 3 safar)",
    "«Tirbandlik» tugmasi bilan yo'l yuklanishini ko'ring",
    "«Svetofor» bilan chorrahaga svetofor qo'ying",
    "«Aylana» bilan aylana chorraha quring",
    "Mamnuniyatni oshirib 2-darajaga chiqing",
  ];
  double get _startBudgetFor => const [4500.0, 3000.0, 2000.0][difficulty];
  final List<Offset> roundabouts = [];
  static const double roundaboutRadius = 30;
  String? flash;
  double _flashT = 0;

  double _acc = 0;
  double _hudTimer = 0;

  // kamera
  Offset cam = const Offset(3200, 3200);
  double zoom = 0.8;

  // chizish holati: 0 bo'sh, 1 sudrash, 2 egish kutilmoqda, 3 egishni sudrash
  int stage = 0;
  Offset? _a, _b, _c;

  // pointerlar
  final Map<int, Offset> _ptrs = {};
  Offset _downPos = Offset.zero;
  bool _moved = false;
  bool _multi = false;
  double _lastDist = 0;
  Offset _lastMid = Offset.zero;

  @override
  Color backgroundColor() => const Color(0xFFBFD9EE);

  // ---------------------------------------------------------------- xarita

  /// Xarita yaratish. Xato bo'lsa ekranda ko'rsatiladi (qotib qolmaydi).
  Future<void> newMap(int s,
      {int? biome, int? difficulty, bool? sandbox, bool ideal = false, double? world, bool realRoads = true}) async {
    _wantWorld = world ?? Terrain.bigSize;
    _importReal = realRoads;
    if (biome != null) this.biome = biome;
    if (difficulty != null) this.difficulty = difficulty;
    if (sandbox != null) this.sandbox = sandbox;
    loadError = null;
    try {
      await _newMapImpl(s);
      if (ideal) {
        try {
          if (this.biome == Terrain.tashkent && _importReal) {
            _applyRealCity();
          } else {
            _applyIdealCity();
          }
        } catch (e) {
          flashMsg("Tayyor shahar qurilmadi: $e");
        }
      }
    } catch (e, st) {
      loadError = '$e\n${st.toString().split("\n").take(3).join("\n")}';
      loading = true;
      hud.value++;
    }
  }

  double _wantWorld = Terrain.bigSize;
  bool _importReal = true; // Toshkent: haqiqiy yo'llar yuklansinmi (saqlashdan yuklashda yo'q)
  List<RealRoad> _real = const []; // Toshkentning haqiqiy yo'llari (hudud kengayganda qo'shiladi)
  final Map<int, Rect> _bbox = {}; // yo'l chegara to'rtburchagi (ko'rinadigan oynaga chizish uchun)

  Future<void> _newMapImpl(int s) async {
    loading = true;
    loadStatus = "Relyef yaratilmoqda...";
    seed = s;
    stage = 0;
    currentPlan = null;
    hud.value++;
    terrain = Terrain(s, biome, _wantWorld);
    terrainImage = await terrain.toImage();
    terrHalf = terrain.size <= Terrain.legacySize ? terrain.size / 2 : terrStart; // eski kichik dunyoda hudud butun xarita
    loadStatus = "Binolar joylashtirilmoqda...";
    hud.value++;
    net.clear();
    _bbox.clear();
    railNet.clear();
    rail.stations.clear();
    rail.rebuild();
    railVis.runs.clear();
    railCoverage = 0;
    roundabouts.clear();
    graph = LaneGraph(net);
    sim = TrafficSim(graph, buildings, s);
    sim.demandScale = const [0.7, 1.0, 1.4][difficulty];
    budget = sandbox ? 1e9 : _startBudgetFor;
    demand = 1.0;
    selected = null;
    rot = 0;
    _undo.clear();
    _redo.clear();
    histVeh.clear();
    histSat.clear();
    histTrip.clear();
    histCong.clear();
    level = 1;
    satisfaction = 50;
    levelTimer = 0;
    _tripsAtLevel = 0;
    satNote = "";
    tutorial = !sandbox;
    tutStep = 0;
    _heatSeen = false;
    _real = biome == Terrain.tashkent ? await RealRoads.load() : const [];
    if (_importReal) importRealRoads(-1, terrHalf); // yo'llar avval, keyin binolar (binolar yo'ldan uzoqda joylashadi)
    _placeBuildings();
    _camStart = cam;
    _zoomStart = zoom;
    _onNetworkChanged();
    loading = false;
    _notify();
  }

  /// Temir yo'l yoki stansiyalar o'zgardi: poyezdlar va ko'rinish qayta quriladi.
  void onRailsChanged() {
    rail.rebuild();
    railVis.rebuild(railNet, net, terrain);
  }

  void onNetworkChanged() => _onNetworkChanged();

  void _onNetworkChanged() {
    if (railNet.roads.isNotEmpty) railVis.rebuild(railNet, net, terrain); // yangi yo'l temir yo'lni kesib o'tishi mumkin
    graph.rebuild();
    graph.computeAccess(buildings);
    sim.onGraphChanged();
    noAccess = buildings.where((b) => !graph.access.containsKey(b.id)).length;
  }

  bool _landDisk(Offset p, double r) {
    if (!terrain.isBuildableAt(p)) return false;
    for (var i = 0; i < 12; i++) {
      final a = i / 12 * 2 * pi;
      if (!terrain.isBuildableAt(p + Offset(cos(a), sin(a)) * r)) return false;
    }
    return true;
  }

  static const _houseRoofs = [Color(0xFFC9694F), Color(0xFF7FA66B), Color(0xFFD9A441), Color(0xFF8C6E5D)];
  static const _shopRoofs = [Color(0xFF5B8DD6), Color(0xFF4F7FC4)];
  static const _factoryRoofs = [Color(0xFF9A9DA3), Color(0xFF8B8F96)];

  void _placeBuildings() {
    final rnd = Random(seed);
    buildings.clear();
    _nextBuildingId = 1;
    Offset? center;
    final wc = worldCenter;
    if (biome == Terrain.tashkent) {
      center = wc; // Amir Temur xiyoboni
    } else {
      for (final rad in const [300.0, 220.0, 150.0, 100.0]) {
        for (var i = 0; i < 3000 && center == null; i++) {
          final p = wc + Offset((rnd.nextDouble() - 0.5) * 1600, (rnd.nextDouble() - 0.5) * 1600);
          if (_landDisk(p, rad)) center = p;
        }
        if (center != null) break;
      }
    }
    cityCenter = center ?? wc;
    cam = cityCenter;
    zoom = 0.9;
    _placeBatch(rnd, 14, 4, 2, 420);
  }

  /// Yangi binolar to'plamini joylashtiradi (mavjud binolar va yo'llardan uzoqda).
  void _placeBatch(Random rnd, int houses, int shops, int factories, double reach) {
    void place(BuildingType type, int count, Size size, List<Color> roofs) {
      for (var k = 0; k < count; k++) {
        for (var t = 0; t < 400; t++) {
          final ang = rnd.nextDouble() * 2 * pi;
          final dist = sqrt(rnd.nextDouble()) * reach;
          final p = cityCenter + Offset(cos(ang), sin(ang)) * dist;
          final r = size.longestSide / 2 + 8;
          if (!inTerritory(p, r + 30) || !terrain.isBuildableAt(p)) continue;
          if (!terrain.isBuildableAt(p + Offset(r, 0)) ||
              !terrain.isBuildableAt(p + Offset(-r, 0)) ||
              !terrain.isBuildableAt(p + Offset(0, r)) ||
              !terrain.isBuildableAt(p + Offset(0, -r))) {
            continue;
          }
          if (buildings.any((b) => (b.pos - p).distance < 90)) continue;
          if (net.nearestRoadPoint(p, r + 10) != null) continue;
          buildings.add(Building(
            id: _nextBuildingId++,
            type: type,
            pos: p,
            angle: rnd.nextInt(4) * pi / 2 + (rnd.nextDouble() - 0.5) * 0.3,
            size: size,
            roof: roofs[rnd.nextInt(roofs.length)],
          ));
          break;
        }
      }
    }

    place(BuildingType.house, houses, const Size(34, 26), _houseRoofs);
    place(BuildingType.shop, shops, const Size(52, 34), _shopRoofs);
    place(BuildingType.factory, factories, const Size(70, 46), _factoryRoofs);
  }

  // ------------------------------------------------------- mamnuniyat va darajalar

  /// Mamnuniyat (0-100) = 45% yo'lga ulanish + 25% safar vaqti + 20% oqim tezligi + 10% muvaffaqiyatli safarlar.
  void _push(List<double> l, double v) {
    l.add(v);
    if (l.length > 90) l.removeAt(0);
  }

  void _econTick() {
    _histT += 1;
    if (_histT >= 2) {
      _histT = 0;
      _push(histVeh, sim.vehicles.length.toDouble());
      _push(histSat, satisfaction);
      _push(histTrip, sim.avgTrip);
      var withV = 0, bad = 0;
      for (final l in graph.lanes.values) {
        if (l.vehicles.isNotEmpty) {
          withV++;
          if (l.ratio < 0.4) bad++;
        }
      }
      _push(histCong, withV == 0 ? 0.0 : 100.0 * bad / withV);
    }
    // mashinalar soni darajaga qarab o'sadi (tarmoq ortiqcha yuklanib qotib qolmasin)
    sim.maxVehicles = sandbox ? 250 : min(250, 100 + 25 * level);

    // ekologiya: ifloslanish (zavodgacha masofa) va shovqin (yaqin mashinalar, yuk mashinasi 2x)
    final factories = buildings.where((b) => b.type == BuildingType.factory).toList();
    final vpos = [for (final v in sim.vehicles) (v.track.pointAt(v.s), v.type == VType.truck ? 2.0 : 1.0)];
    var expoSum = 0.0;
    var houses = 0;
    envExpo.clear();
    for (final b in buildings) {
      if (b.type != BuildingType.house) continue;
      var pol = 0.0;
      for (final f in factories) {
        final d = (f.pos - b.pos).distance;
        if (d < 250) pol += 1 - d / 250;
      }
      var noise = 0.0;
      for (final p in vpos) {
        final d = (p.$1 - b.pos).distance;
        if (d < 110) noise += (1 - d / 110) * p.$2;
      }
      final e = min(1.0, 0.6 * min(1.0, pol) + 0.4 * min(1.0, noise / 3.0));
      envExpo[b.id] = e;
      expoSum += e;
      houses++;
    }
    env = houses == 0 ? 1.0 : 1 - expoSum / houses;

    // temir yo'l: xizmat zonasidagi uylar mashinada kamroq yuradi va mamnuniyat oshadi
    railCoverage = rail.coverage([for (final b in buildings) if (b.type == BuildingType.house) b.pos]);
    sim.demandScale = const [0.7, 1.0, 1.4][difficulty] * demand * (1 - 0.3 * railCoverage);

    // ta'minot: do'konlar zaxirasi va xizmat ko'rsatish ulushi (yuk mashinalari tirbandlikda qolsa, pasayadi)
    final shops = buildings.where((b) => b.type == BuildingType.shop).toList();
    if (shops.isEmpty) {
      supply = 1.0;
    } else {
      final avgStock = shops.fold<double>(0, (s, b) => s + b.stock) / shops.length / 100;
      final tot = sim.served + sim.unserved;
      final service = tot < 5 ? 1.0 : sim.served / tot;
      supply = 0.5 * avgStock + 0.5 * service;
    }

    final total = buildings.length;
    final access = total == 0 ? 0.0 : (total - noAccess) / total;
    final commute = sim.completed < 3
        ? 0.5
        : (1 - (sim.avgTrip - 20) / 80).clamp(0.0, 1.0).toDouble();
    var sum = 0.0;
    for (final l in graph.lanes.values) {
      sum += l.ratio;
    }
    final flow = graph.lanes.isEmpty ? 0.0 : sum / graph.lanes.length;
    final failFrac = sim.failed / (sim.failed + sim.completed + 1);
    final raw = min(100.0, 100 * (0.37 * access + 0.20 * commute + 0.17 * flow + 0.07 * (1 - failFrac) + 0.11 * env + 0.08 * supply) + 6 * railCoverage);
    satisfaction += (raw - satisfaction) * 0.15;

    if (noAccess > 0) {
      satNote = "Yo'lga ulanmagan binolar: $noAccess";
    } else if (commute < 0.5) {
      satNote = "Safarlar juda uzoq davom etyapti";
    } else if (flow < 0.6) {
      satNote = "Tirbandlik mamnuniyatni pasaytiryapti";
    } else if (env < 0.6) {
      satNote = "Zavod ifloslanishi va shovqin uylarni bezovta qilyapti";
    } else if (supply < 0.5) {
      satNote = "Do'konlarda tovar yetishmayapti";
    } else {
      satNote = "Tarmoq yaxshi ishlayapti";
    }

    final ok = satisfaction >= satTarget && noAccess == 0 && (sim.completed - _tripsAtLevel) >= 6;
    levelTimer = ok ? levelTimer + 1 : max(0.0, levelTimer - 1);
    if (levelTimer >= levelNeedSeconds && level < maxLevel && !sandbox) _levelUp();
  }

  /// Shahar o'sishi bilan xarita hududi kengayadi (daraja boshiga terrStep). Kengaygan bo'lsa true.
  bool _growTerritory() => expandTerritory(min(worldSize / 2 - 60, terrStart + terrStep * (level - 1)));

  /// Hududni [target] gacha kengaytiradi; Toshkentda yangi ochilgan halqadagi haqiqiy yo'llar qo'shiladi.
  bool expandTerritory(double target) {
    if (target <= terrHalf + 1) return false;
    final old = terrHalf;
    terrHalf = target;
    if (_importReal && _real.isNotEmpty) {
      importRealRoads(old, target);
      onNetworkChanged();
    }
    return true;
  }

  /// Markazdan Chebyshev masofasi (from, to] oralig'idagi haqiqiy yo'llarni qo'shadi (narxsiz); qo'shilgan soni.
  int importRealRoads(double from, double to) {
    var n = 0;
    for (final r in _real) {
      if (r.cheb <= from || r.cheb > to) continue;
      if (net.addRoadPts(List<Offset>.of(r.pts), oneWay: r.oneWay, type: r.type, layer: r.layer, cost: 0) != null) n++;
    }
    return n;
  }

  void _levelUp() {
    level++;
    levelTimer = 0;
    final bonus = const [2000.0, 1500.0, 1000.0][difficulty];
    budget += bonus;
    _tripsAtLevel = sim.completed;
    final before = buildings.length;
    final grew = _growTerritory();
    _placeBatch(Random(seed * 31 + level), 3 + level ~/ 2, level.isEven ? 1 : 0,
        level % 3 == 0 ? 1 : 0, min(420 + 60.0 * level, terrHalf - 150));
    _onNetworkChanged();
    _feedback(big: true);
    flashMsg("Daraja $level! +${bonus.round()} mablag', yangi binolar: ${buildings.length - before}"
        "${grew ? ". Hudud kengaydi" : ""}");
  }

  // ------------------------------------------------------------ tayyor ("ideal") shahar

  /// O'yin ochilganda tayyor shahar turadi. Yakuniy bosqichda `false` qilinadi: o'yin bo'sh boshlanadi.
  static const bool idealCityOnStart = true;

  bool _free(Offset p, double pad) =>
      !terrain.isWaterAt(p) && !buildings.any((b) => b.containsPoint(p, pad));

  /// Bino va suvdan xoli eng uzun to'g'ri chiziqni qidiradi (markaz atrofida). (boshi, oxiri, siljish)
  (Offset, Offset, double)? _bestLine(bool horizontal, {double? notNear}) {
    final c = cityCenter;
    final dir = horizontal ? const Offset(1, 0) : const Offset(0, 1);
    (Offset, Offset, double)? best;
    var bestScore = -1e9;
    for (final o in const [0.0, 25.0, -25.0, 50.0, -50.0, 75.0, -75.0, 100.0, -100.0, 130.0, -130.0, 160.0, -160.0, 200.0, -200.0, 240.0, -240.0]) {
      if (notNear != null && (o - notNear).abs() < 110) continue;
      final origin = horizontal ? c + Offset(0, o) : c + Offset(o, 0);
      if (!_free(origin, 14)) continue;
      double ext(double sign) {
        var t = 0.0;
        while (t < 430 && _free(origin + dir * (sign * (t + 10)), 14)) {
          t += 10;
        }
        return t;
      }

      final a = ext(-1);
      final b = ext(1);
      if (a + b < 260) continue;
      final score = a + b - o.abs() * 0.6;
      if (score > bestScore) {
        bestScore = score;
        best = (origin - dir * a, origin + dir * b, o);
      }
    }
    return best;
  }

  bool _buildLine((Offset, Offset, double)? l, int type, {double reserve = 150}) {
    if (l == null) return false;
    final pts = RoadNetwork.sample(l.$1, l.$2, null);
    final cost = RoadNetwork.polyLength(pts) * RoadNetwork.costPerUnit * RoadNetwork.costFactor(type);
    if (cost > budget - reserve) return false;
    net.connectRoad(pts, type: type);
    budget -= cost;
    return true;
  }

  Offset? _crossPoint((Offset, Offset, double)? h, (Offset, Offset, double)? v) {
    if (h == null || v == null) return null;
    final p = Offset(cityCenter.dx + v.$3, cityCenter.dy + h.$3);
    final inH = p.dx >= min(h.$1.dx, h.$2.dx) && p.dx <= max(h.$1.dx, h.$2.dx);
    final inV = p.dy >= min(v.$1.dy, v.$2.dy) && p.dy <= max(v.$1.dy, v.$2.dy);
    return inH && inV ? p : null;
  }

  /// Siniq chiziq; sinish nuqtalari yumaloqlanadi (mashina tirsakda keskin burilmasin).
  List<Offset> _poly(List<Offset> w) {
    final out = <Offset>[w.first];
    var from = w.first;
    for (var i = 1; i < w.length; i++) {
      final v = w[i];
      if (i == w.length - 1) {
        out.addAll(RoadNetwork.sample(from, v, null).skip(1));
        break;
      }
      final d1 = (v - w[i - 1]).distance, d2 = (w[i + 1] - v).distance;
      final d = min(14.0, 0.4 * min(d1, d2));
      if (d < 3) {
        out.addAll(RoadNetwork.sample(from, v, null).skip(1));
        from = v;
        continue;
      }
      final a = v + (w[i - 1] - v) / d1 * d;
      final b = v + (w[i + 1] - v) / d2 * d;
      out.addAll(RoadNetwork.sample(from, a, null).skip(1));
      for (var k = 1; k <= 6; k++) {
        final t = k / 6, q = 1 - t;
        out.add(Offset(
          q * q * a.dx + 2 * q * t * v.dx + t * t * b.dx,
          q * q * a.dy + 2 * q * t * v.dy + t * t * b.dy,
        ));
      }
      from = b;
    }
    return out;
  }

  /// Binoning old nuqtasidan eng yaqin yo'lga mahalliy yo'l: to'g'ri, egri (turli bukilish) yoki
  /// siniq chiziq variantlari sinab ko'riladi; bino/suvga tegmaydigan, boshqa yo'lni kesmaydigani olinadi.
  bool _linkBuilding(Building b) {
    final f = b.frontPoint;
    if (net.nearestRoadPoint(f, 6.0, layer: 0) != null) return true; // yo'lning o'zida
    final cands = <Offset>[];
    for (final r in net.roads.values) {
      if (r.layer != 0 || r.oneWay) continue;
      for (var i = 1; i < r.pts.length; i++) {
        cands.add(closestOnSegment(f, r.pts[i - 1], r.pts[i]));
      }
    }
    cands.sort((p, q) => (p - f).distance.compareTo((q - f).distance));
    final picked = <Offset>[];
    for (final c in cands) {
      if (picked.length >= 24) break;
      if (picked.every((p) => (p - c).distance > 15)) picked.add(c);
    }
    final fd = Offset(-sin(b.angle), cos(b.angle));
    final side = Offset(-fd.dy, fd.dx);
    for (final t in picked) {
      final dist = (t - f).distance;
      if (dist < 6) return true;
      final paths = <List<Offset>>[RoadNetwork.sample(f, t, null)];
      for (final len in const [35.0, 60.0, 90.0]) {
        final ctrl = f + fd * min(len, dist * 0.7);
        if (!_tooSharp(f, t, ctrl)) paths.add(RoadNetwork.sample(f, t, ctrl));
      }
      for (final len in const [45.0, 70.0]) {
        for (final sd in const [-60.0, 60.0]) {
          final ctrl = f + fd * len + side * sd;
          if (!_tooSharp(f, t, ctrl)) paths.add(RoadNetwork.sample(f, t, ctrl));
        }
      }
      for (final len in const [30.0, 50.0, 80.0]) {
        final w1 = f + fd * len;
        paths.add(_poly([f, w1, t]));
        for (final sd in const [-50.0, 50.0]) {
          paths.add(_poly([f, w1, w1 + side * sd, t]));
        }
      }
      for (final pts in paths) {
        final plen = RoadNetwork.polyLength(pts);
        if (plen < 8) continue;
        if (_hitsBuilding(pts) || pts.any(terrain.isWaterAt)) continue;
        var crosses = false;
        for (final p in pts) {
          if ((p - t).distance < 16 || (p - f).distance < 10) continue;
          if (net.nearestRoadPoint(p, 6.0, layer: 0) != null) {
            crosses = true;
            break;
          }
        }
        if (crosses) continue;
        final cost = plen * RoadNetwork.costPerUnit;
        if (cost > budget - 120) continue;
        net.connectRoad(pts, type: 0);
        budget -= cost;
        return true;
      }
    }
    return false;
  }

  /// Mavjud asboblar bilan shahar: ikki katta yo'l, ular kesishmasida aylana chorraha,
  /// parallel yo'l va svetoforli chorraha, hamma binoga mahalliy yo'l.
  void _applyIdealCity() {
    roadType = 0;
    roadLayer = 0;
    budget = 1e9; // reja byudjetga bog'lanmaydi; shahar tayyor bo'lgach qolgan mablag' belgilanadi
    final h1 = _bestLine(true);
    final v = _bestLine(false);
    final h2 = h1 == null ? null : _bestLine(true, notNear: h1.$3);
    if (!_buildLine(h1, 1)) _buildLine(h1, 0);
    if (!_buildLine(v, 1)) _buildLine(v, 0);

    // asosiy kesishma: aylana chorraha (bo'lmasa svetofor)
    final p1 = _crossPoint(h1, v);
    if (p1 != null) {
      final n = net.nodeNear(p1, 6);
      if (n != null && n.roads.length >= 3) {
        final center = n.pos;
        var spent = 0.0;
        final err = net.buildRoundabout(
          n.id,
          roundaboutRadius,
          (p) => terrain.isWaterAt(p) || buildings.any((b) => (b.pos - p).distance < b.radius),
          budget,
          (d) => spent += d,
        );
        if (err == null) {
          budget -= spent;
          roundabouts.add(center);
        } else {
          _onNetworkChanged();
          sim.addSignal(n.id, 12);
        }
      }
    }

    // parallel yo'l va unda svetoforli chorraha
    _buildLine(h2, 0);
    final p2 = _crossPoint(h2, v);
    if (p2 != null) {
      final n = net.nodeNear(p2, 6);
      if (n != null && n.roads.length >= 3) {
        _onNetworkChanged();
        sim.addSignal(n.id, 12);
      }
    }

    // hamma binoga mahalliy yo'l (markazga yaqinidan boshlab)
    final order = [...buildings]
      ..sort((a, b) => (a.pos - cityCenter).distance.compareTo((b.pos - cityCenter).distance));
    for (final b in order) {
      _linkBuilding(b);
    }

    roadType = 0;
    roadLayer = 0;
    budget = sandbox ? 1e9 : const [1500.0, 1000.0, 700.0][difficulty];
    tutorial = false;
    cam = cityCenter;
    zoom = 0.5;
    _clampCam();
    _undo.clear();
    _redo.clear();
    _onNetworkChanged();
    _notify();
    flashMsg("Tayyor shahar yuklandi");
  }

  /// Toshkent: haqiqiy ko'chalar allaqachon yuklangan; binolar mahalliy yo'l bilan ulanadi, asosiy chorrahalarga svetofor qo'yiladi.
  void _applyRealCity() {
    roadType = 0;
    roadLayer = 0;
    budget = 1e9; // mahalliy yo'llar byudjetga bog'lanmaydi; tayyor bo'lgach qolgan mablag' belgilanadi
    final order = [...buildings]
      ..sort((a, b) => (a.pos - cityCenter).distance.compareTo((b.pos - cityCenter).distance));
    for (final b in order) {
      _linkBuilding(b);
    }
    _onNetworkChanged();
    final cands = <(double, RoadNode)>[];
    for (final n in net.nodes.values) {
      if (n.roads.length < 3 || !inTerritory(n.pos, 30)) continue;
      var oneWays = 0, big = 0;
      for (final id in n.roads) {
        final r = net.roads[id];
        if (r == null) continue;
        if (r.oneWay) oneWays++;
        if (r.type == 1) big++;
      }
      if (n.roads.length == 3 && oneWays > 0) continue; // aylana kirish/chiqishi, qo'shilish
      if (n.roads.length >= 4 || big >= 2) cands.add(((n.pos - cityCenter).distance, n));
    }
    cands.sort((a, b) => a.$1.compareTo(b.$1));
    for (final c in cands.take(24)) {
      sim.addSignal(c.$2.id, 12, adaptive: true);
    }
    roadType = 0;
    roadLayer = 0;
    budget = sandbox ? 1e9 : const [1500.0, 1000.0, 700.0][difficulty];
    tutorial = false;
    cam = cityCenter;
    zoom = 0.6;
    _clampCam();
    _undo.clear();
    _redo.clear();
    _onNetworkChanged();
    _notify();
    flashMsg("Toshkent ko'chalari yuklandi");
  }

  // ---------------------------------------------------------- saqlash/yuklash

  Future<bool> save({bool auto = false, int slot = 1}) async {
    if (loading) return false;
    try {
      final sp = await SharedPreferences.getInstance();
      final key = auto ? 'autosave' : 'save$slot';
      final old = sp.getString(key);
      if (old != null) await sp.setString('${key}_prev', old);
      final data = jsonEncode({
        'v': 2,
        'ts': DateTime.now().toIso8601String(),
        'seed': seed,
        'budget': budget,
        'level': level,
        'biome': biome,
        'ws': worldSize,
        'th': terrHalf,
        'diff': difficulty,
        'sbx': sandbox ? 1 : 0,
        'buildings': [for (final b in buildings) b.toJson()],
        'cam': [cam.dx, cam.dy],
        'zoom': zoom,
        'roads': [
          for (final r in net.roads.values)
            {
              'p': [for (final p in r.pts) ...[p.dx, p.dy]],
              'o': r.oneWay ? 1 : 0,
              't': r.type,
              'l': r.layer,
              if (r.cost <= 0) 'f': 1, // tayyor (tekin) yo'l: o'chirilganda mablag' qaytmaydi
            }
        ],
        'signals': [
          for (final s in sim.signals.values)
            [graph.net.nodes[s.nodeId]!.pos.dx, graph.net.nodes[s.nodeId]!.pos.dy, s.green, s.adaptive ? 1.0 : 0.0]
        ],
        'rbs': [
          for (final c in roundabouts) [c.dx, c.dy]
        ],
        'rails': [
          for (final r in railNet.roads.values)
            {
              'p': [for (final p in r.pts) ...[p.dx, p.dy]],
              'l': r.layer,
            }
        ],
        'stations': [
          for (final st in rail.stations) [st.pos.dx, st.pos.dy]
        ],
      });
      await sp.setString(key, data);
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Uya haqida qisqa ma'lumot (0 = avtosaqlash).
  Future<String?> slotInfo(int slot) async {
    try {
      final sp = await SharedPreferences.getInstance();
      final raw = sp.getString(slot == 0 ? 'autosave' : 'save$slot');
      if (raw == null) return null;
      final m = jsonDecode(raw) as Map<String, dynamic>;
      final ts = (m['ts'] as String?) ?? '';
      final when = ts.length >= 16 ? ts.substring(0, 16).replaceFirst('T', ' ') : '';
      return "Daraja ${(m['level'] as num?)?.toInt() ?? 1} · ${(m['roads'] as List).length} yo'l · $when";
    } catch (_) {
      return null;
    }
  }

  Future<bool> load({int? slot}) async {
    final SharedPreferences sp;
    try {
      sp = await SharedPreferences.getInstance();
    } catch (_) {
      return false;
    }
    final keys = slot == null
        ? ['save1', 'save1_prev', 'autosave', 'autosave_prev']
        : (slot == 0 ? ['autosave', 'autosave_prev'] : ['save$slot', 'save${slot}_prev']);
    for (final key in keys) {
      final raw = sp.getString(key);
      if (raw == null) continue;
      try {
        final m = jsonDecode(raw) as Map<String, dynamic>;
        final ver = m['v'];
        if (ver != 1 && ver != 2) continue;
        final s = m['seed'] as int;
        final bud = (m['budget'] as num).toDouble();
        final lvl = (m['level'] as num?)?.toInt() ?? 1;
        final bio = (m['biome'] as num?)?.toInt() ?? 0;
        final ws = (m['ws'] as num?)?.toDouble() ?? (bio == Terrain.tashkent ? Terrain.bigSize : Terrain.legacySize);
        final dif = (m['diff'] as num?)?.toInt() ?? 1;
        final sbx = (m['sbx'] as num?)?.toInt() == 1;
        final savedB = <Building>[];
        var bid = 1;
        for (final e in (m['buildings'] as List? ?? const [])) {
          savedB.add(Building.fromJson(bid++, e as Map<String, dynamic>));
        }
        final c = (m['cam'] as List).map((e) => (e as num).toDouble()).toList();
        final z = (m['zoom'] as num).toDouble();
        final roads = <List<Offset>>[];
        final oneWays = <bool>[];
        final types = <int>[];
        final layers = <int>[];
        final frees = <bool>[];
        for (final r in m['roads'] as List) {
          final raw = r is Map ? r['p'] : r;
          final f = (raw as List).map((e) => (e as num).toDouble()).toList();
          if (f.length < 4 || f.length.isOdd) throw const FormatException('road');
          roads.add([for (var i = 0; i < f.length; i += 2) Offset(f[i], f[i + 1])]);
          oneWays.add(r is Map && r['o'] == 1);
          types.add(r is Map ? ((r['t'] as num?)?.toInt() ?? 0) : 0);
          layers.add(r is Map ? ((r['l'] as num?)?.toInt() ?? 0) : 0);
          frees.add(r is Map && r['f'] == 1);
        }
        final sigs = <List<double>>[
          for (final e in (m['signals'] as List? ?? const []))
            [for (final x in e as List) (x as num).toDouble()]
        ];
        final rbs = <List<double>>[
          for (final e in (m['rbs'] as List? ?? const []))
            [for (final x in e as List) (x as num).toDouble()]
        ];
        final railPts = <List<Offset>>[];
        final railLayers = <int>[];
        for (final r in (m['rails'] as List? ?? const [])) {
          final f = ((r as Map)['p'] as List).map((e) => (e as num).toDouble()).toList();
          if (f.length < 4 || f.length.isOdd) throw const FormatException('rail');
          railPts.add([for (var i = 0; i < f.length; i += 2) Offset(f[i], f[i + 1])]);
          railLayers.add((r['l'] as num?)?.toInt() ?? 0);
        }
        final stationPts = <Offset>[
          for (final e in (m['stations'] as List? ?? const []))
            Offset(((e as List)[0] as num).toDouble(), (e[1] as num).toDouble())
        ];
        await newMap(s, biome: bio, difficulty: dif, sandbox: sbx, world: ws, realRoads: false);
        _importReal = true; // keyingi hudud kengayishlarida haqiqiy yo'llar qo'shiladi
        terrHalf = ((m['th'] as num?)?.toDouble() ?? terrHalf).clamp(terrStart, terrain.size / 2).toDouble();
        for (var i = 0; i < roads.length; i++) {
          net.addRoadPts(roads[i], oneWay: oneWays[i], type: types[i], layer: layers[i], cost: frees[i] ? 0.0 : null);
        }
        for (final r in rbs) {
          roundabouts.add(Offset(r[0], r[1]));
        }
        for (var i = 0; i < railPts.length; i++) {
          railNet.addRoadPts(railPts[i], layer: railLayers[i]);
        }
        for (final p in stationPts) {
          rail.addStation(p);
        }
        onRailsChanged();
        _onNetworkChanged();
        for (final sg in sigs) {
          final nd = net.nodeNear(Offset(sg[0], sg[1]), 2.0);
          if (nd != null) sim.addSignal(nd.id, sg[2], adaptive: sg.length > 3 && sg[3] == 1);
        }
        if (savedB.isNotEmpty) {
          buildings
            ..clear()
            ..addAll(savedB);
          _nextBuildingId = savedB.length + 1;
        }
        level = lvl;
        tutorial = false;
        budget = bud;
        cam = Offset(c[0], c[1]);
        zoom = z.clamp(minZoom, maxZoom).toDouble();
        _onNetworkChanged();
        _notify();
        return true;
      } catch (_) {
        continue; // buzilgan fayl: oldingi zaxira nusxaga o'tamiz
      }
    }
    return false;
  }

  // ---------------------------------------------------------------- kamera

  Offset _rot(Offset v, double a) {
    final c = cos(a), s = sin(a);
    return Offset(v.dx * c - v.dy * s, v.dx * s + v.dy * c);
  }

  Offset toWorld(Offset s) =>
      cam + _rot(Offset((s.dx - size.x / 2) / zoom, (s.dy - size.y / 2) / zoom), -rot);

  /// Dunyo nuqtasi w ekrandagi s joyda qolishi uchun kamerani moslaydi.
  void _anchor(Offset w, Offset s) {
    cam = w - _rot(Offset((s.dx - size.x / 2) / zoom, (s.dy - size.y / 2) / zoom), -rot);
  }

  /// Dunyo nuqtasi -> ekran (render bilan bir xil: translate, scale, rotate, translate).
  Offset worldToScreen(Offset w) =>
      Offset(size.x / 2, size.y / 2) + _rot(w - cam, rot) * zoom;

  String debugText() {
    final t = _lastTouch;
    if (t == null) return "DEBUG: ekranga tegib ko'ring";
    final w = toWorld(t);
    final back = worldToScreen(w);
    final g = lastGlobal;
    String f(double v, [int d = 1]) => v.toStringAsFixed(d);
    return "touch (${f(t.dx)}, ${f(t.dy)}) -> world (${f(w.dx)}, ${f(w.dy)}) -> back (${f(back.dx)}, ${f(back.dy)})  d=${f((back - t).distance, 3)}\n"
        "global-local d=${g == null ? '-' : f((g - t).distance)} | game ${f(size.x, 0)}x${f(size.y, 0)} widget ${f(widgetSize.width, 0)}x${f(widgetSize.height, 0)} | dpr ${f(dpr, 2)}\n"
        "cam (${cam.dx.round()}, ${cam.dy.round()}) zoom ${f(zoom, 2)} rot ${f(rot, 2)}\n"
        "fps ${f(fps, 0)} | sim ${f(simMs, 1)} ms | mashina ${sim.vehicles.length} | polosa ${graph.lanes.length} | marshrut ${graph.routeCalls}";
  }

  void toggleColorBlind() {
    colorBlind = !colorBlind;
    hud.value++;
  }

  void toggleSound() {
    soundOn = !soundOn;
    hud.value++;
  }

  void _feedback({bool big = false}) {
    if (!soundOn) return;
    if (big) {
      HapticFeedback.heavyImpact();
      SystemSound.play(SystemSoundType.alert);
    } else {
      HapticFeedback.lightImpact();
      SystemSound.play(SystemSoundType.click);
    }
  }

  _EditState _capture(double refund) => _EditState(
        [for (final rd in net.roads.values) (List<Offset>.of(rd.pts), rd.oneWay, rd.type, rd.layer, rd.cost)],
        List<Offset>.of(roundabouts),
        [
          for (final s in sim.signals.values)
            if (net.nodes[s.nodeId] != null) (net.nodes[s.nodeId]!.pos, s.green, s.adaptive)
        ],
        refund,
        [for (final rd in railNet.roads.values) (List<Offset>.of(rd.pts), rd.oneWay, rd.type, rd.layer)],
        [for (final st in rail.stations) st.pos],
      );

  /// Tahrirdan OLDIN chaqiriladi; tahrir muvaffaqiyatli bo'lsa _endEdit bilan yakunlanadi.
  _EditState _beginEdit() => _capture(0);

  void _endEdit(_EditState before, double spent) {
    _undo.add(_EditState(before.roads, before.roundabouts, before.signals, spent, before.rails, before.stations));
    if (_undo.length > 30) _undo.removeAt(0);
    _redo.clear();
  }

  void _restore(_EditState s) {
    net.clear(resetIds: false); // eski polosa id'lari qayta ishlatilmasin
    sim.signals.clear();
    roundabouts
      ..clear()
      ..addAll(s.roundabouts);
    for (final rd in s.roads) {
      net.addRoadPts(List<Offset>.of(rd.$1), oneWay: rd.$2, type: rd.$3, layer: rd.$4, cost: rd.$5);
    }
    _onNetworkChanged();
    for (final sg in s.signals) {
      final nd = net.nodeNear(sg.$1, 2.0);
      if (nd != null) sim.addSignal(nd.id, sg.$2, adaptive: sg.$3);
    }
    railNet.clear(resetIds: false);
    for (final rd in s.rails) {
      railNet.addRoadPts(List<Offset>.of(rd.$1), type: rd.$3, layer: rd.$4);
    }
    rail.stations.clear();
    for (final p in s.stations) {
      rail.addStation(p);
    }
    onRailsChanged();
    selected = null;
    stage = 0;
  }

  void undo() {
    if (_undo.isEmpty) return;
    final e = _undo.removeLast();
    final cur = _capture(-e.refund);
    _restore(e);
    budget += e.refund;
    _redo.add(cur);
    _notify();
    flashMsg("Bekor qilindi");
  }

  void redo() {
    if (_redo.isEmpty) return;
    final e = _redo.removeLast();
    final cur = _capture(-e.refund);
    _restore(e);
    budget += e.refund;
    _undo.add(cur);
    _notify();
    flashMsg("Qaytarildi");
  }

  void cycleGridSpacing() {
    const opts = [80, 110, 150, 200];
    gridSpacing = opts[(opts.indexOf(gridSpacing) + 1) % opts.length];
    _notify();
  }

  /// To'rtburchak ko'cha to'ri: ko'rinish yo'nalishiga mos ikki o'q bo'ylab chiziqlar.
  void _computeGrid() {
    gridPlans = [];
    gridInfo = "";
    if (tool != Tool.grid || stage != 1 || _a == null || _b == null) return;
    final a = _a!, b = _b!;
    final u = _rot(const Offset(1, 0), -rot);
    final v = _rot(const Offset(0, 1), -rot);
    final d = b - a;
    final du = d.dx * u.dx + d.dy * u.dy;
    final dv = d.dx * v.dx + d.dy * v.dy;
    if (du.abs() < gridSpacing * 0.8 || dv.abs() < gridSpacing * 0.8) {
      gridInfo = "Maydon juda kichik";
      return;
    }
    final nu = (du.abs() / gridSpacing).floor();
    final nv = (dv.abs() / gridSpacing).floor();
    if ((nu + 1) + (nv + 1) > 24) {
      gridInfo = "Juda ko'p yo'l (oraliqni kattalashtiring)";
      return;
    }
    final su = du >= 0 ? 1.0 : -1.0;
    final sv = dv >= 0 ? 1.0 : -1.0;
    for (var j = 0; j <= nv; j++) {
      final p0 = a + v * (sv * j * gridSpacing);
      gridPlans.add(_buildPlan(p0, p0 + u * (su * du.abs()), null));
    }
    for (var i = 0; i <= nu; i++) {
      final p0 = a + u * (su * i * gridSpacing);
      gridPlans.add(_buildPlan(p0, p0 + v * (sv * dv.abs()), null));
    }
    final ok = gridPlans.where((p) => p.error == null || p.error == "Mablag' yetarli emas").toList();
    final skipped = gridPlans.length - ok.length;
    final total = ok.fold<double>(0, (s, p) => s + p.cost);
    gridInfo = "${ok.length} yo'l · narx ${total.round()}${skipped > 0 ? ' · $skipped o\'tkaziladi' : ''}";
    if (total > budget) gridInfo = "Mablag' yetarli emas (${total.round()})";
  }

  void _buildGrid() {
    _computeGrid();
    final ok = [
      for (final p in gridPlans)
        if (p.error == null || p.error == "Mablag' yetarli emas") p
    ];
    if (ok.isEmpty) {
      flashMsg(gridInfo.isEmpty ? "Yo'l qurib bo'lmaydi" : gridInfo);
      return;
    }
    final total = ok.fold<double>(0, (s, p) => s + p.cost);
    if (total > budget) {
      flashMsg("Mablag' yetarli emas");
      return;
    }
    final before = _beginEdit();
    for (final p in ok) {
      net.connectRoad(p.pts, type: roadType, layer: roadLayer);
    }
    budget -= total;
    _onNetworkChanged();
    _endEdit(before, total);
    _feedback();
    flashMsg("To'r qurildi: ${ok.length} yo'l (${total.round()})");
  }

  void toggleEnv() {
    showEnv = !showEnv;
    hud.value++;
  }

  void toggleDebug() {
    debug = !debug;
    hud.value++;
  }

  void resetRotation() {
    rot = 0;
    hud.value++;
  }

  void _clampCam() {
    final c = worldCenter;
    final lim = terrHalf + 200;
    cam = Offset(
      cam.dx.clamp(c.dx - lim, c.dx + lim).toDouble(),
      cam.dy.clamp(c.dy - lim, c.dy + lim).toDouble(),
    );
  }

  void wheel(Offset pos, double dy) {
    final before = toWorld(pos);
    zoom = (zoom * exp(-dy * 0.0015)).clamp(minZoom, maxZoom).toDouble();
    _anchor(before, pos);
    _clampCam();
  }

  void _initPinch() {
    final p = _ptrs.values.take(2).toList();
    _lastMid = (p[0] + p[1]) / 2;
    _lastDist = (p[0] - p[1]).distance;
    _lastAng = atan2(p[1].dy - p[0].dy, p[1].dx - p[0].dx);
    _twist = 0;
    _rotating = false;
  }

  void _pinch() {
    final p = _ptrs.values.take(2).toList();
    final mid = (p[0] + p[1]) / 2;
    final dist = (p[0] - p[1]).distance;
    final ang = atan2(p[1].dy - p[0].dy, p[1].dx - p[0].dx);
    if (_lastDist > 0 && dist > 0) {
      final before = toWorld(_lastMid);
      zoom = (zoom * dist / _lastDist).clamp(minZoom, maxZoom).toDouble();
      var da = ang - _lastAng;
      while (da > pi) {
        da -= 2 * pi;
      }
      while (da < -pi) {
        da += 2 * pi;
      }
      _twist += da;
      if (!_rotating && _twist.abs() > 0.15) _rotating = true; // tasodifiy burilishdan himoya
      if (_rotating && dist > 60) rot += da;
      _anchor(before, mid);
    }
    _lastMid = mid;
    _lastDist = dist;
    _lastAng = ang;
    _clampCam();
  }

  // ------------------------------------------------------------- boshqaruv

  void setTool(Tool t) {
    tool = t;
    stage = 0;
    _notify();
  }

  void cancel() {
    stage = 0;
    _notify();
  }

  void cycleSpeed() {
    speed = speed == 1 ? 2 : (speed == 2 ? 4 : (speed == 4 ? 0 : 1));
    hud.value++;
  }

  Offset _snap(Offset w) {
    if (railMode) {
      final n = railNet.nodeNear(w, 40 / zoom);
      if (n != null) return n.pos;
      final want = roadLayer == 3 ? 1 : 0;
      var h = railNet.nearestRoadPoint(w, 28 / zoom, layer: want);
      if (h == null && want == 1) h = railNet.nearestRoadPoint(w, 28 / zoom, layer: 0); // tunnel og'zi yer usti yo'liga ulanadi
      return h?.point ?? w;
    }
    final n = net.nodeNear(w, 40 / zoom);
    if (n != null) return n.pos;
    // binoga yaqinlashsa, avtomatik uning old tomoniga tushadi
    Building? bb;
    var bdist = double.infinity;
    // radius ekran pikselida (34 px): dunyo birligida emas, shuning uchun zoom'da barmoqdan uzoqqa sakramaydi
    final pad = min(120.0, max(6.0, 34 / zoom));
    for (final b in buildings) {
      if (!b.containsPoint(w, pad)) continue;
      final d = (b.pos - w).distance;
      if (d < bdist) {
        bdist = d;
        bb = b;
      }
    }
    if (bb != null) return bb.frontPoint;
    var h = net.nearestRoadPoint(w, 28 / zoom, layer: roadLayer);
    if (h == null && roadLayer == 1) h = net.nearestRoadPoint(w, 28 / zoom, layer: 0);
    return h?.point ?? w;
  }

  void pointerDown(int id, Offset pos) {
    if (loading) return;
    _ptrs[id] = pos;
    if (_ptrs.length >= 2) {
      _multi = true;
      _dragScreen = null;
      if (stage == 1) stage = 0;
      if (stage == 3) stage = 2;
      _initPinch();
      _notify();
      return;
    }
    _multi = false;
    _downPos = pos;
    _dragScreen = pos;
    _lastTouch = pos;
    _moved = false;
    final w = toWorld(pos);
    switch (tool) {
      case Tool.straight:
        stage = 1;
        _a = _snap(w);
        _b = _a;
        break;
      case Tool.grid:
        if (railMode) {
          flashMsg("To'r faqat yo'llar uchun");
          break;
        }
        stage = 1;
        _a = w;
        _b = w;
        break;
      case Tool.curve:
        if (stage == 2) {
          stage = 3;
          _c = w;
        } else {
          stage = 1;
          _a = _snap(w);
          _b = _a;
        }
        break;
      default:
        break;
    }
    _notify();
  }

  void pointerMove(int id, Offset pos) {
    final prev = _ptrs[id];
    if (prev == null) return;
    _ptrs[id] = pos;
    if (_ptrs.length >= 2) {
      _pinch();
      return;
    }
    if (_multi) return;
    if ((pos - _downPos).distance > 8) _moved = true;
    _dragScreen = pos;
    _lastTouch = pos;
    switch (tool) {
      case Tool.pan:
        cam -= _rot((pos - prev) / zoom, -rot);
        _clampCam();
        break;
      case Tool.grid:
        if (stage == 1) _b = toWorld(pos);
        break;
      case Tool.straight:
      case Tool.curve:
        if (stage == 1) {
          _b = _snap(toWorld(pos));
        } else if (stage == 3) {
          _c = toWorld(pos);
        }
        break;
      case Tool.signal:
      case Tool.roundabout:
      case Tool.erase:
      case Tool.building:
      case Tool.inspect:
      case Tool.station:
        break;
    }
    _notify();
  }

  void pointerUp(int id) {
    final pos = _ptrs.remove(id);
    if (pos == null) return;
    _dragScreen = null;
    if (_multi) {
      if (_ptrs.isEmpty) _multi = false;
      return;
    }
    switch (tool) {
      case Tool.erase:
        if (!_moved) _eraseAt(toWorld(pos));
        break;
      case Tool.straight:
        if (stage == 1) {
          final p = currentPlan;
          if (p != null && p.valid) _commit(p);
          stage = 0;
        }
        break;
      case Tool.curve:
        if (stage == 1) {
          if (_moved && (_b! - _a!).distance >= minRoadLength) {
            stage = 2;
            _c = (_a! + _b!) / 2;
          } else {
            stage = 0;
          }
        } else if (stage == 3) {
          final p = currentPlan;
          if (p != null && p.valid) {
            _commit(p);
            stage = 0;
          } else {
            stage = 2;
          }
        }
        break;
      case Tool.signal:
        if (!_moved) _tapSignal(toWorld(pos));
        break;
      case Tool.roundabout:
        if (!_moved) _tapRoundabout(toWorld(pos));
        break;
      case Tool.grid:
        if (stage == 1) {
          _buildGrid();
          stage = 0;
        }
        break;
      case Tool.building:
        if (!_moved) _tapBuilding(toWorld(pos));
        break;
      case Tool.inspect:
        if (!_moved) _tapInspect(toWorld(pos));
        break;
      case Tool.station:
        if (!_moved) _tapStation(toWorld(pos));
        break;
      case Tool.pan:
        break;
    }
    _notify();
  }

  void _eraseAt(Offset w) {
    final tol = 14 / zoom + 8;
    // stansiya
    for (final st in rail.stations) {
      if ((st.pos - w).distance < tol + 14) {
        final before = _beginEdit();
        rail.stations.remove(st);
        budget += RailConst.stationCost;
        onRailsChanged();
        _endEdit(before, -RailConst.stationCost);
        _feedback();
        return;
      }
    }
    final rr = railNet.nearestRoadPoint(w, tol, layer: 1) ?? railNet.nearestRoadPoint(w, tol);
    final hasRoad = net.nearestRoadPoint(w, tol) != null;
    if (rr != null && (railMode || !hasRoad)) {
      final refund = RailVis.analyze(rr.road.pts, rr.road.layer, terrain).cost;
      final before = _beginEdit();
      railNet.removeRoad(rr.road.id);
      var back = refund;
      rail.stations.removeWhere((st) {
        final gone = railNet.nodeNear(st.pos, 4) == null;
        if (gone) back += RailConst.stationCost;
        return gone;
      });
      budget += back;
      onRailsChanged();
      _endEdit(before, -back);
      _feedback();
      return;
    }
    final r = (net.nearestRoadPoint(w, 14 / zoom + 8, layer: 1) ?? net.nearestRoadPoint(w, 14 / zoom + 8))?.road;
    if (r == null) return;
    final before = _beginEdit();
    budget += r.cost; // to'liq qaytarish
    net.removeRoad(r.id);
    _onNetworkChanged();
    _endEdit(before, -r.cost);
    _feedback();
  }

  void _commitRail(RoadPlan p) {
    final before = _beginEdit();
    final layer = roadLayer == 3 ? 1 : 0;
    railNet.connectRoad(p.pts, type: 0, layer: layer);
    budget -= p.cost;
    onRailsChanged();
    _endEdit(before, p.cost);
    _feedback();
    final an = RailVis.analyze(p.pts, layer, terrain);
    flashMsg(an.hasBridge
        ? "Temir yo'l ko'prigi qurildi (${p.cost.round()})"
        : (an.hasTunnel ? "Tunnel qurildi (${p.cost.round()})" : "Temir yo'l qurildi (${p.cost.round()})"));
  }

  /// Stansiya: temir yo'lning yer usti qismiga bosiladi, o'sha joyda yo'l bo'linadi va tugun stansiyaga aylanadi.
  void _tapStation(Offset w) {
    final h = railNet.nearestRoadPoint(w, 20 / zoom + 10, layer: 0);
    if (h == null) {
      flashMsg("Stansiyani temir yo'l ustiga qo'ying");
      return;
    }
    final p = h.point;
    if (!inTerritory(p, 30)) {
      flashMsg("Hudud tashqarisida");
      return;
    }
    if (RailVis.classOf(p, 0, terrain, net) != RailCls.ground) {
      flashMsg("Stansiya faqat yer ustidagi, yo'ldan xoli joyga qo'yiladi");
      return;
    }
    if (rail.stations.any((st) => (st.pos - p).distance < 150)) {
      flashMsg("Stansiyalar orasi kamida 150 birlik bo'lsin");
      return;
    }
    if (RailConst.stationCost > budget) {
      flashMsg("Mablag' yetarli emas");
      return;
    }
    final before = _beginEdit();
    final node = railNet.splitRoadAt(h.road.id, p);
    rail.addStation(node.pos);
    budget -= RailConst.stationCost;
    onRailsChanged();
    _endEdit(before, RailConst.stationCost);
    _feedback();
    flashMsg("Stansiya qurildi (${RailConst.stationCost.round()})");
  }

  void _commit(RoadPlan p) {
    if (railMode) {
      _commitRail(p);
      return;
    }
    final before = _beginEdit();
    var loose = false;
    for (final e in [p.a, p.b]) {
      final joined = net.nodeNear(e, 14) != null || net.nearestRoadPoint(e, 12) != null;
      final atBuilding = buildings.any((b) => (b.frontPoint - e).distance < 3);
      if (!joined && !atBuilding && net.nearestRoadPoint(e, 45) != null) loose = true;
    }
    net.connectRoad(p.pts, type: roadType, layer: roadLayer);
    budget -= p.cost;
    _onNetworkChanged();
    _endEdit(before, p.cost);
    _feedback();
    if (loose) flashMsg("Diqqat: yo'l uchi yaqin yo'lga ulanmadi. Uchini yo'lga yaqinlashtiring");
  }

  // -------------------------------------------------------------- yo'l rejasi

  void cycleRoadLayer() {
    roadLayer = (roadLayer + 1) % 4;
    if (railMode && tool == Tool.grid) tool = Tool.straight;
    _notify();
  }

  void cycleRoadType() {
    roadType = (roadType + 1) % 3;
    _notify();
  }

  void cycleBuildType() {
    buildType = (buildType + 1) % 3;
    hud.value++;
  }

  void cycleDemand() {
    const opts = [0.5, 1.0, 2.0, 4.0];
    final i = opts.indexOf(demand);
    demand = opts[(i + 1) % opts.length];
    sim.demandScale = const [0.7, 1.0, 1.4][difficulty] * demand * (1 - 0.3 * railCoverage);
    hud.value++;
  }

  void _tapBuilding(Offset w) {
    final size = const [Size(34, 26), Size(52, 34), Size(70, 46)][buildType];
    final r = size.longestSide / 2 + 8;
    if (!inTerritory(w, r)) {
      flashMsg("Hudud tashqarisida");
      return;
    }
    if (!terrain.isBuildableAt(w) ||
        !terrain.isBuildableAt(w + Offset(r, 0)) ||
        !terrain.isBuildableAt(w + Offset(-r, 0)) ||
        !terrain.isBuildableAt(w + Offset(0, r)) ||
        !terrain.isBuildableAt(w + Offset(0, -r))) {
      flashMsg("Bu yerga bino qurib bo'lmaydi");
      return;
    }
    if (buildings.any((b) => (b.pos - w).distance < 90) || net.nearestRoadPoint(w, r + 10) != null) {
      flashMsg("Joy band yoki yo'l juda yaqin");
      return;
    }
    buildings.add(Building(
      id: _nextBuildingId++,
      type: BuildingType.values[buildType],
      pos: w,
      angle: 0,
      size: size,
      roof: [_houseRoofs[0], _shopRoofs[0], _factoryRoofs[0]][buildType],
    ));
    _onNetworkChanged();
  }

  /// Mashina, chorraha yoki yo'l haqida ma'lumot (haqiqiy simulyatsiya ma'lumotlari).
  void _tapInspect(Offset w) {
    selected = null;
    Vehicle? bv;
    var bd = 14 / zoom + 10;
    for (final v in sim.vehicles) {
      final d = (v.track.pointAt(v.s) - w).distance;
      if (d < bd) {
        bd = d;
        bv = v;
      }
    }
    if (bv != null) {
      selected = bv;
      flashMsg("Mashina #${bv.id}: ${(bv.v * 1.8).round()} km/s, safar ${(sim.time - bv.born).round()} s, manzil: bino #${bv.destB}");
      return;
    }
    for (final st in rail.stations) {
      if ((st.pos - w).distance < 24 / zoom + 20) {
        flashMsg("Stansiya: xizmat zonasida ${st.served} uy, poyezd to'xtashlari ${st.visits}, "
            "${st.active ? 'poyezd qatnaydi' : 'ikkinchi stansiya kerak'}");
        return;
      }
    }
    for (final t in rail.trains) {
      if ((rail.poseAt(t, t.length / 2).p - w).distance < 30 / zoom + 24) {
        flashMsg("Poyezd #${t.id}: ${(t.v * 1.8).round()} km/s");
        return;
      }
    }
    for (final b in buildings) {
      if (!b.containsPoint(w, 4)) continue;
      final linked = graph.access.containsKey(b.id) ? 'bor' : "yo'q";
      switch (b.type) {
        case BuildingType.house:
          flashMsg("Uy: ekologik yuk ${((envExpo[b.id] ?? 0) * 100).round()}%, yo'lga ulangan: $linked");
          break;
        case BuildingType.shop:
          flashMsg("Do'kon: zaxira ${b.stock.round()}%, yo'lga ulangan: $linked");
          break;
        case BuildingType.factory:
          flashMsg("Zavod: ifloslanish manbai (250 birlik atrofida), yo'lga ulangan: $linked");
          break;
      }
      return;
    }
    final node = net.nodeNear(w, 26 / zoom + 10);
    if (node != null && node.roads.length >= 3) {
      final sg = sim.signals[node.id];
      flashMsg("Chorraha: ${node.roads.length} yo'l, svetofor: ${sg != null ? (sg.adaptive ? 'bor (adaptiv)' : 'bor (yashil ${sg.green.round()} s)') : 'yo\'q'}, kutayotgan mashinalar: ${sim.waitingAt(node.id)}");
      return;
    }
    final hit = net.nearestRoadPoint(w, 14 / zoom + 8);
    if (hit != null) {
      final rd = hit.road;
      final ls = graph.lanesOf(rd.id);
      final cnt = ls.fold<int>(0, (s, l) => s + l.vehicles.length);
      final limit = (ls.isEmpty ? 22.0 : ls.first.speedLimit) * 1.8;
      flashMsg("${rd.type == 1 ? 'Katta yo\'l' : 'Oddiy yo\'l'}: limit ${limit.round()} km/s, oqim ${(_roadRatio(rd) * 100).round()}%, mashinalar: $cnt, uzunligi ${rd.length.round()} m");
      return;
    }
    flashMsg("Bu yerda ma'lumot yo'q");
  }

  bool _tutDone(int i) {
    switch (i) {
      case 0:
        return (cam - _camStart).distance > 80 || (zoom - _zoomStart).abs() > 0.15 || rot.abs() > 0.2;
      case 1:
        return net.roads.isNotEmpty;
      case 2:
        return net.roads.isNotEmpty && noAccess == 0;
      case 3:
        return sim.completed >= 3;
      case 4:
        return _heatSeen;
      case 5:
        return sim.signals.isNotEmpty;
      case 6:
        return roundabouts.isNotEmpty;
      default:
        return level >= 2;
    }
  }

  void _tutTick() {
    if (!tutorial || loading) return;
    while (tutStep < tutorialTexts.length && _tutDone(tutStep)) {
      tutStep++;
    }
    if (tutStep >= tutorialTexts.length) {
      tutorial = false;
      flashMsg("O'rgatish tugadi. Omad!");
    }
  }

  void skipTutorial() {
    tutorial = false;
    hud.value++;
  }

  void toggleCharts() {
    showCharts = !showCharts;
    hud.value++;
  }

  /// Eng og'ir tirbandlik joyi: ko'p mashina va past oqim tezligi.
  Road? worstRoad() {
    Road? best;
    var bestScore = 0.0;
    for (final r in net.roads.values) {
      final cnt = graph.lanesOf(r.id).fold<int>(0, (s, l) => s + l.vehicles.length);
      if (cnt < 4) continue;
      final score = cnt * (1 - _roadRatio(r));
      if (score > bestScore) {
        bestScore = score;
        best = r;
      }
    }
    return best;
  }

  void focusBottleneck() {
    final r = worstRoad();
    if (r == null) {
      flashMsg("Jiddiy tirbandlik topilmadi");
      return;
    }
    cam = r.pts[r.pts.length ~/ 2];
    zoom = 1.6;
    heat = true;
    _clampCam();
    final cnt = graph.lanesOf(r.id).fold<int>(0, (s, l) => s + l.vehicles.length);
    flashMsg("Eng og'ir joy: $cnt mashina, oqim ${(_roadRatio(r) * 100).round()}%");
  }

  void flashMsg(String m) {
    flash = m;
    _flashT = 2.5;
    hud.value++;
  }

  void toggleHeat() {
    heat = !heat;
    if (heat) _heatSeen = true;
    hud.value++;
  }

  void _tapSignal(Offset w) {
    final n = net.nodeNear(w, 26 / zoom + 10);
    if (n == null || n.roads.length < 3) {
      flashMsg("Chorraha ustiga bosing (kamida 3 yo'l)");
      return;
    }
    final before = _beginEdit();
    flashMsg(sim.cycleSignal(n.id));
    _endEdit(before, 0);
    _feedback();
  }

  void _tapRoundabout(Offset w) {
    final n = net.nodeNear(w, 26 / zoom + 10);
    if (n == null || n.roads.length < 3) {
      flashMsg("Chorraha ustiga bosing (kamida 3 yo'l)");
      return;
    }
    final center = n.pos;
    var spent = 0.0;
    final before = _beginEdit();
    final err = net.buildRoundabout(
      n.id,
      roundaboutRadius,
      (p) => terrain.isWaterAt(p) || buildings.any((b) => (b.pos - p).distance < b.radius),
      budget,
      (d) => spent += d,
    );
    if (err != null) {
      flashMsg(err);
      return;
    }
    budget -= spent;
    roundabouts.add(center);
    _onNetworkChanged();
    _endEdit(before, spent);
    _feedback();
    flashMsg("Aylana chorraha qurildi (${spent.round()})");
  }

  bool _tooSharp(Offset a, Offset b, Offset c, [double minAngle = 0.9]) {
    final va = a - c, vb = b - c;
    final la = va.distance, lb = vb.distance;
    if (la < 1 || lb < 1) return true;
    final cosA = ((va.dx * vb.dx + va.dy * vb.dy) / (la * lb)).clamp(-1.0, 1.0).toDouble();
    return acos(cosA) < minAngle; // yo'l ~52 daraja, temir yo'l ~97 daraja
  }

  /// Yo'l markaz chizig'i (yarim kenglik bilan) bino maydoniga tegadimi: haqiqiy geometriya,
  /// har 4 birlikda tekshiriladi (oraliqdagi burchakni o'tkazib yubormaydi).
  bool _hitsBuilding(List<Offset> pts) {
    final pad = railMode ? 12.0 : const [6.5, 13.0, 20.0][roadType];
    for (final bd in buildings) {
      for (var i = 0; i < pts.length; i++) {
        if (bd.containsPoint(pts[i], pad)) return true;
        if (i == 0) continue;
        final d = (pts[i] - pts[i - 1]).distance;
        final n = (d / 4).ceil();
        for (var k = 1; k < n; k++) {
          if (bd.containsPoint(Offset.lerp(pts[i - 1], pts[i], k / n)!, pad)) return true;
        }
      }
    }
    return false;
  }

  /// Temir yo'l rejasi: suv ustida ko'prik, tog'da tunnel (yoki yer osti rejimida butunlay tunnel).
  RoadPlan _buildRailPlan(Offset a, Offset b, Offset? c) {
    final pts = RoadNetwork.sample(a, b, c);
    final len = RoadNetwork.polyLength(pts);
    final layer = roadLayer == 3 ? 1 : 0;
    final an = RailVis.analyze(pts, layer, terrain);
    String? err;
    if (len < 60) {
      err = "Juda qisqa";
    } else if (c != null && _tooSharp(a, b, c, 1.9)) {
      err = "Burchak juda keskin";
    } else if (!inTerritory(a) || !inTerritory(b) || !inTerritory(pts[pts.length ~/ 2])) {
      err = "Hudud tashqarisida";
    } else if (terrain.isWaterAt(a) || terrain.isWaterAt(b)) {
      err = "Ko'prik uchlari quruqlikda bo'lishi kerak";
    } else if (layer == 0 && (terrain.isMountainAt(a) || terrain.isMountainAt(b))) {
      err = "Tunnel og'zi tog'dan tashqarida bo'lishi kerak";
    } else if (an.longestBridge > RailVis.maxBridge) {
      err = "Ko'prik juda uzun";
    } else if (an.longestTunnel > RailVis.maxTunnel) {
      err = "Tunnel juda uzun";
    } else if (layer == 0 && _hitsBuilding(pts)) {
      err = "Yo'l binoga tegmoqda";
    } else if (an.cost > budget) {
      err = "Mablag' yetarli emas";
    }
    return RoadPlan(a, b, c, pts, len, an.cost, err);
  }

  RoadPlan _buildPlan(Offset a, Offset b, Offset? c) {
    if (railMode) return _buildRailPlan(a, b, c);
    final pts = RoadNetwork.sample(a, b, c);
    final len = RoadNetwork.polyLength(pts);
    final cost = len * RoadNetwork.costPerUnit * RoadNetwork.costFactor(roadType) * (roadLayer == 1 ? 1.5 : 1.0);
    String? err;
    if (len < minRoadLength) {
      err = "Juda qisqa";
    } else if (c != null && _tooSharp(a, b, c)) {
      err = "Burchak juda keskin";
    } else if (!inTerritory(a) || !inTerritory(b) || !inTerritory(pts[pts.length ~/ 2])) {
      err = "Hudud tashqarisida";
    } else if (roadLayer == 1 ? (terrain.isWaterAt(a) || terrain.isWaterAt(b)) : pts.any(terrain.isWaterAt)) {
      err = roadLayer == 1 ? "Ko'prik uchlari quruqlikda bo'lishi kerak" : "Suv ustiga yo'l qurib bo'lmaydi";
    } else if (_hitsBuilding(pts)) {
      err = "Yo'l binoga tegmoqda";
    } else if (cost > budget) {
      err = "Mablag' yetarli emas";
    }
    return RoadPlan(a, b, c, pts, len, cost, err);
  }

  RoadPlan? _computePlan() {
    if (stage == 0 || _a == null || _b == null || tool == Tool.grid) return null;
    if (stage == 1) return _buildPlan(_a!, _b!, null);
    return _buildPlan(_a!, _b!, _c ?? (_a! + _b!) / 2);
  }

  void _notify() {
    currentPlan = _computePlan();
    _computeGrid();
    hud.value++;
  }

  // ----------------------------------------------------------------- yangilash

  @override
  void update(double dt) {
    super.update(dt);
    _fpsAcc += dt;
    _fpsN++;
    if (_fpsAcc >= 1) {
      fps = _fpsN / _fpsAcc;
      _fpsAcc = 0;
      _fpsN = 0;
    }
    if (loading || menuOpen) return;
    final ds = _dragScreen;
    if (ds != null && (stage == 1 || stage == 3)) {
      // chizayotganda barmoq ekran chetiga yetsa, xarita o'zi suriladi
      const side = 60.0, top = 160.0, bottom = 240.0;
      var vx = 0.0, vy = 0.0;
      if (ds.dx < side) vx = -(side - ds.dx) / side;
      if (ds.dx > size.x - side) vx = (ds.dx - (size.x - side)) / side;
      if (ds.dy < top) vy = -(top - ds.dy) / top;
      if (ds.dy > size.y - bottom) vy = (ds.dy - (size.y - bottom)) / bottom;
      if (vx != 0 || vy != 0) {
        cam += _rot(Offset(vx, vy) * (450 / zoom * dt), -rot);
        _clampCam();
        if (stage == 1) {
          _b = tool == Tool.grid ? toWorld(ds) : _snap(toWorld(ds));
        } else {
          _c = toWorld(ds);
        }
        _notify();
      }
    }
    if (_flashT > 0) {
      _flashT -= dt;
      if (_flashT <= 0) {
        flash = null;
        hud.value++;
      }
    }
    if (speed > 0) {
      _acc += min(dt, 0.1) * speed;
      var n = 0;
      final sw = Stopwatch()..start();
      while (_acc >= _simStep && n < 10) {
        sim.step(_simStep);
        rail.step(_simStep);
        _acc -= _simStep;
        n++;
      }
      simMs = sw.elapsedMicroseconds / 1000.0;
      if (_acc > _simStep) _acc = 0; // qurilma ulgurmasa, tezlikni pasaytiramiz
    }
    if (speed > 0) {
      _econTimer += dt;
      if (_econTimer >= 1.0) {
        _econTimer -= 1.0;
        _econTick();
      }
    }
    _hudTimer += dt;
    if (_hudTimer > 0.3) {
      _hudTimer = 0;
      _tutTick();
      hud.value++;
    }
  }

  // ----------------------------------------------------------------- chizish

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    if (loading || terrainImage == null) return;

    canvas.save();
    canvas.translate(size.x / 2, size.y / 2);
    canvas.scale(zoom);
    canvas.rotate(rot);
    canvas.translate(-cam.dx, -cam.dy);

    _drawTerrain(canvas);
    _drawRoads(canvas);
    for (final b in buildings) {
      b.draw(canvas);
    }
    _drawEnv(canvas);
    _drawVehicles(canvas, 0);
    _drawSignals(canvas);
    drawRails(canvas, railVis, zoom);
    drawStations(canvas, rail);
    _drawElevated(canvas); // estakada yer usti mashinalari va binolar ustidan o'tadi
    _drawVehicles(canvas, 1);
    drawTrains(canvas, rail, railVis, zoom);
    _drawSelected(canvas);
    _drawPreview(canvas);

    canvas.restore();
    _drawDebug(canvas);
  }

  void _drawTerrain(Canvas canvas) {
    final img = terrainImage!;
    canvas.drawImageRect(
      img,
      Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()),
      Rect.fromLTWH(0, 0, worldSize, worldSize),
      Paint()..filterQuality = FilterQuality.high,
    );
    final c = worldCenter;
    if (terrHalf < worldSize / 2 - 1) {
      // hali ochilmagan hudud: xarita shahar o'sishi bilan ochilib boradi
      final inner = Rect.fromCenter(center: c, width: terrHalf * 2, height: terrHalf * 2);
      final fog = Path()
        ..fillType = PathFillType.evenOdd
        ..addRect(Rect.fromLTWH(-20000, -20000, worldSize + 40000, worldSize + 40000))
        ..addRect(inner);
      canvas.drawPath(fog, Paint()..color = const Color(0xFFE6E3DA));
      canvas.drawRect(
        inner,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = max(2.0, 2.5 / zoom)
          ..color = const Color(0xFF8C8F96),
      );
    }
    if (biome == Terrain.tashkent) {
      final lbl = _centerLabel ??= (ParagraphBuilder(ParagraphStyle(textAlign: TextAlign.center))
            ..pushStyle(TextStyle(color: const Color(0xFF3F4A3C), fontSize: 13, fontWeight: FontWeight.w600))
            ..addText("Amir Temur xiyoboni"))
          .build()
        ..layout(const ParagraphConstraints(width: 220));
      canvas.save();
      canvas.translate(c.dx, c.dy);
      canvas.rotate(-rot);
      canvas.scale(1 / zoom);
      canvas.drawParagraph(lbl, const Offset(-110, 18));
      canvas.restore();
    }
  }

  Path _pathOf(List<Offset> pts) {
    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (var i = 1; i < pts.length; i++) {
      path.lineTo(pts[i].dx, pts[i].dy);
    }
    return path;
  }

  static const _heatPos = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0];
  static const _heatCol = [
    Color(0xFF7A1F1F), // juda og'ir tirbandlik
    Color(0xFFD0392B),
    Color(0xFFE8873A),
    Color(0xFFE9C94A),
    Color(0xFF8CCB5E),
    Color(0xFF4CAF50), // erkin harakat
  ];

  // ko'r odamlar uchun palitra (Okabe-Ito'ga yaqin): ko'k -> sariq -> to'q sariq -> binafsha
  static const _heatColCb = [
    Color(0xFF4B1D6B),
    Color(0xFF9B3D8F),
    Color(0xFFE67E22),
    Color(0xFFF4D03F),
    Color(0xFF7FB5E6),
    Color(0xFF2E86C1),
  ];

  Color _heatColor(double r) {
    final cols = colorBlind ? _heatColCb : _heatCol;
    final x = r.clamp(0.0, 1.0).toDouble();
    for (var i = 1; i < _heatPos.length; i++) {
      if (x <= _heatPos[i]) {
        final t = (x - _heatPos[i - 1]) / (_heatPos[i] - _heatPos[i - 1]);
        return Color.lerp(cols[i - 1], cols[i], t)!;
      }
    }
    return cols.last;
  }

  double _roadRatio(Road r) {
    var m = 1.0;
    for (final l in graph.lanesOf(r.id)) {
      if (l.ratio < m) m = l.ratio;
    }
    return m;
  }

  bool _ringExists(Offset c) => net.roads.values.any((r) =>
      r.oneWay &&
      r.pts.length > 2 &&
      ((r.pts[r.pts.length ~/ 2] - c).distance - roundaboutRadius).abs() < 3);

  /// Ekrandagi dunyo to'rtburchagi (burilgan kamerada ham), [pad] bilan kengaytirilgan.
  Rect _viewRect([double pad = 60]) {
    final cs = [toWorld(Offset.zero), toWorld(Offset(size.x, 0)), toWorld(Offset(0, size.y)), toWorld(Offset(size.x, size.y))];
    var x0 = cs[0].dx, x1 = cs[0].dx, y0 = cs[0].dy, y1 = cs[0].dy;
    for (final c in cs) {
      x0 = min(x0, c.dx);
      x1 = max(x1, c.dx);
      y0 = min(y0, c.dy);
      y1 = max(y1, c.dy);
    }
    return Rect.fromLTRB(x0 - pad, y0 - pad, x1 + pad, y1 + pad);
  }

  Rect _bboxOf(Road r) => _bbox.putIfAbsent(r.id, () {
        var x0 = r.pts[0].dx, x1 = x0, y0 = r.pts[0].dy, y1 = y0;
        for (final p in r.pts) {
          x0 = min(x0, p.dx);
          x1 = max(x1, p.dx);
          y0 = min(y0, p.dy);
          y1 = max(y1, p.dy);
        }
        return Rect.fromLTRB(x0, y0, x1, y1);
      });

  static const Color _asphalt = Color(0xFFDADCDF);
  static const Color _edge = Color(0xFF4A4D52);

  double _wOf(Road r) => RoadNetwork.roadWidth * (r.type + 1);

  void _drawRoads(Canvas canvas) {
    if (net.roads.isEmpty) return;
    const w = RoadNetwork.roadWidth;
    final view = _viewRect(RoadNetwork.roadWidth * 3 + 10);
    final roads = net.roads.values.where((r) => r.layer == 0 && view.overlaps(_bboxOf(r))).toList();
    if (roads.isNotEmpty) {
      final paths = [for (final r in roads) _pathOf(r.pts)];
      final border = Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..color = _edge;
      final fill = Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;
      for (var i = 0; i < roads.length; i++) {
        border.strokeWidth = _wOf(roads[i]) + 5;
        canvas.drawPath(paths[i], border);
      }
      for (var i = 0; i < roads.length; i++) {
        fill.strokeWidth = _wOf(roads[i]);
        fill.color = heat ? _heatColor(_roadRatio(roads[i])) : _asphalt;
        canvas.drawPath(paths[i], fill);
      }
      if (!heat) _drawMarkings(canvas, roads);
    }
    if (!heat) {
      final junction = Paint()..color = _asphalt;
      for (final n in net.nodes.values) {
        if (n.roads.length >= 3 && view.contains(n.pos)) canvas.drawCircle(n.pos, w * 0.66, junction);
      }
    }
    roundabouts.removeWhere((c) => !_ringExists(c));
    for (final c in roundabouts) {
      canvas.drawCircle(c, roundaboutRadius - 8, Paint()..color = const Color(0xFFB5CC7E));
      canvas.drawCircle(
        c,
        roundaboutRadius - 8,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = _edge,
      );
    }
  }

  /// Yo'l belgilari: ikki tomonlama oddiy yo'lda sariq punktir, katta yo'l/magistralda sariq ajratgich,
  /// polosalar orasida oq punktir. Uzoqdan (kichik masshtabda) chizilmaydi.
  void _drawMarkings(Canvas canvas, List<Road> roads) {
    if (zoom < 0.3) return;
    final solid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = const Color(0xCCD9B85A);
    final yellow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..color = const Color(0xCCD9B85A);
    final white = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = const Color(0xCCFFFFFF);
    final yellowDashes = <Offset>[];
    final whiteDashes = <Offset>[];
    for (final r in roads) {
      if (!r.oneWay) {
        if (r.type == 0) {
          _dash(r.pts, 6, 8, yellowDashes);
        } else {
          canvas.drawPath(_pathOf(r.pts), solid);
        }
      }
      if (r.type == 0) continue;
      for (final off in r.type == 2 ? const [-14.0, -7.0, 7.0, 14.0] : const [-7.0, 7.0]) {
        _dash(LaneGraph.offsetPath(r.pts, off), 5, 7, whiteDashes);
      }
    }
    canvas.drawPoints(PointMode.lines, yellowDashes, yellow);
    canvas.drawPoints(PointMode.lines, whiteDashes, white);
  }

  /// Chiziqni [on] uzunlikda chizilib, [off] uzunlikda tashlab ketiladigan bo'laklarga ajratadi
  /// (har bo'lak [out]ga ikki nuqta bo'lib qo'shiladi).
  static void _dash(List<Offset> pts, double on, double off, List<Offset> out) {
    var drawing = true;
    var left = on;
    for (var i = 1; i < pts.length; i++) {
      final a = pts[i - 1], b = pts[i];
      final len = (b - a).distance;
      if (len < 1e-9) continue;
      var pos = 0.0;
      while (pos < len - 1e-9) {
        final step = min(len - pos, left);
        if (drawing) {
          out.add(Offset.lerp(a, b, pos / len)!);
          out.add(Offset.lerp(a, b, (pos + step) / len)!);
        }
        pos += step;
        left -= step;
        if (left <= 1e-9) {
          drawing = !drawing;
          left = drawing ? on : off;
        }
      }
    }
  }

  /// Estakada yerga tushadigan uchlarida shu masofada (birlik) silliq pasayadi.
  static const double _rampLen = 70;

  /// Tugunga yer usti yo'li ulanganmi (estakada shu yerda rampa bo'lib tushadi).
  bool _touchesGround(int nodeId) {
    final n = net.nodes[nodeId];
    if (n == null) return false;
    for (final rid in n.roads) {
      if (net.roads[rid]?.layer == 0) return true;
    }
    return false;
  }

  /// Estakada uchi yerga tushadimi: yer usti yo'liga ulangan yoki hech narsaga ulanmagan (ko'prik tayanchi).
  bool _grounded(int nodeId) => _touchesGround(nodeId) || (net.nodes[nodeId]?.roads.length ?? 0) <= 1;

  Deck _deckOf(Road r) {
    final pts = <Offset>[r.pts.first];
    final cum = <double>[0];
    var acc = 0.0;
    for (var i = 1; i < r.pts.length; i++) {
      final a = r.pts[i - 1], b = r.pts[i];
      final len = (b - a).distance;
      if (len < 1e-6) continue;
      final n = max(1, (len / 6).ceil());
      for (var k = 1; k <= n; k++) {
        acc += len / n;
        pts.add(Offset.lerp(a, b, k / n)!);
        cum.add(acc);
      }
    }
    final ga = _grounded(r.a), gb = _grounded(r.b);
    final ra = ga ? min(_rampLen, acc / 2) : 0.0;
    final rb = gb ? min(_rampLen, acc / 2) : 0.0;
    final h = <double>[];
    for (final s in cum) {
      var v = 1.0;
      if (ra > 0 && s < ra) v = min(v, s / ra);
      if (rb > 0 && acc - s < rb) v = min(v, (acc - s) / rb);
      h.add(v * v * (3 - 2 * v)); // silliq ko'tarilish
    }
    return Deck(pts, h, _wOf(r) / 2, !ga, !gb, _touchesGround(r.a), _touchesGround(r.b));
  }

  /// Estakada: uchlarida rampa bo'lib yerdan ko'tariladi (soya va chetlari balandlik bilan ortadi),
  /// shuning uchun yer usti yo'liga to'g'ri va ravon qo'shiladi.
  void _drawElevated(Canvas canvas) {
    final view = _viewRect(RoadNetwork.roadWidth * 3 + 10);
    final roads = net.roads.values.where((r) => r.layer == 1 && r.pts.length >= 2 && view.overlaps(_bboxOf(r))).toList();
    if (roads.isEmpty) return;
    final decks = [for (final r in roads) _deckOf(r)];
    final shadow = Paint()
      ..color = const Color(0x55000000)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
    for (final d in decks) {
      canvas.drawPath(d.ribbon(d.half + 1.5, 0, const Offset(5, 7)), shadow);
    }
    final border = Paint()..color = _edge;
    for (final d in decks) {
      canvas.drawPath(d.ribbon(d.half, 3.5, Offset.zero), border);
      if (d.capA) canvas.drawCircle(d.pts.first, d.half + 3.5, border);
      if (d.capB) canvas.drawCircle(d.pts.last, d.half + 3.5, border);
    }
    final fill = Paint();
    for (var i = 0; i < decks.length; i++) {
      final d = decks[i];
      fill.color = heat ? _heatColor(_roadRatio(roads[i])) : _asphalt;
      canvas.drawPath(d.ribbon(d.half, 0, Offset.zero), fill);
      if (d.capA) canvas.drawCircle(d.pts.first, d.half, fill);
      if (d.capB) canvas.drawCircle(d.pts.last, d.half, fill);
    }
    if (!heat) {
      _drawMarkings(canvas, roads);
      final junction = Paint()..color = _asphalt;
      // rampaning yer yo'liga tegadigan uchi: to'rtburchak burchaklar yer yo'li yuzasi bilan yopiladi
      for (final d in decks) {
        if (d.baseA) canvas.drawCircle(d.pts.first, d.half + 0.6, junction);
        if (d.baseB) canvas.drawCircle(d.pts.last, d.half + 0.6, junction);
      }
      for (final n in net.nodes.values) {
        if (n.roads.length >= 3 && view.contains(n.pos) && n.roads.every((id) => net.roads[id]?.layer == 1)) {
          canvas.drawCircle(n.pos, RoadNetwork.roadWidth * 0.7, junction);
        }
      }
    }
  }

  /// Ekologiya qatlami: zavod atrofida ifloslanish, uylarda ekologik yuk (yashil -> qizil).
  void _drawEnv(Canvas canvas) {
    if (!showEnv) return;
    for (final f in buildings) {
      if (f.type != BuildingType.factory) continue;
      canvas.drawCircle(
        f.pos,
        250,
        Paint()..shader = Gradient.radial(f.pos, 250, const [Color(0x66A05A2C), Color(0x00A05A2C)]),
      );
    }
    final p = Paint();
    for (final b in buildings) {
      if (b.type != BuildingType.house) continue;
      final e = envExpo[b.id] ?? 0.0;
      p.color = Color.lerp(const Color(0xFF3DBE5A), const Color(0xFFD64541), e)!;
      canvas.drawCircle(b.pos, 9, p);
      canvas.drawCircle(
        b.pos,
        9,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = const Color(0xFFFFFFFF),
      );
    }
  }

  /// Debug: qizil = barmoq (ekran), sariq = dunyo nuqtasidan ekranga qaytarilgan joy. Mos tushishi kerak.
  void _drawDebug(Canvas canvas) {
    final t = _lastTouch;
    if (!debug || t == null) return;
    final back = worldToScreen(toWorld(t));
    canvas.drawCircle(
      t,
      18,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFFE02020),
    );
    canvas.drawLine(t - const Offset(26, 0), t + const Offset(26, 0), Paint()..color = const Color(0xFFE02020));
    canvas.drawLine(t - const Offset(0, 26), t + const Offset(0, 26), Paint()..color = const Color(0xFFE02020));
    canvas.drawCircle(
      back,
      9,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = const Color(0xFFF2D020),
    );
  }

  void _drawSelected(Canvas canvas) {
    final v = selected;
    if (v == null) return;
    if (v.removed) {
      selected = null;
      return;
    }
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xCC1B8FA0);
    for (var i = v.routeIdx; i < v.route.length; i++) {
      final l = v.route[i];
      if (graph.lanes.containsKey(l.id)) canvas.drawPath(_pathOf(l.pts), paint);
    }
    canvas.drawCircle(
      v.track.pointAt(v.s),
      9,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFF1B8FA0),
    );
  }

  void _drawSignals(Canvas canvas) {
    final p = Paint();
    for (final s in sim.signals.values) {
      for (final l in s.incoming) {
        final st = s.stateOfLane(l.id);
        p.color = st == 0
            ? const Color(0xFF3DBE5A)
            : (st == 1 ? const Color(0xFFF2B233) : const Color(0xFFD64541));
        canvas.drawCircle(l.pointAt(l.length - 3), 3.2, p);
      }
    }
  }

  int _layerOf(Track t) {
    final int rid;
    if (t is Lane) {
      rid = t.roadId;
    } else if (t is Connector) {
      rid = t.from.roadId;
    } else {
      return 0;
    }
    return net.roads[rid]?.layer ?? 0;
  }

  void _drawVehicles(Canvas canvas, int layer) {
    final k = max(1.0, 3.0 / (4.4 * zoom)); // uzoqdan ham ko'rinishi uchun
    final paint = Paint();
    final glass = Paint()..color = const Color(0x55000000);
    for (final v in sim.vehicles) {
      if (_layerOf(v.track) != layer) continue;
      final p = v.track.pointAt(v.s);
      final d = v.track.dirAt(v.s);
      final c = p - d * (v.length * k / 2) + Offset(-d.dy, d.dx) * v.lat; // lat: polosa almashtirish siljishi
      canvas.save();
      canvas.translate(c.dx, c.dy);
      canvas.rotate(atan2(d.dy, d.dx));
      final body = RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset.zero, width: v.length * k, height: v.width * k),
        Radius.circular(1.5 * k),
      );
      paint.color = v.color;
      canvas.drawRRect(body, paint);
      canvas.drawRect(
        Rect.fromLTWH(v.length * k * 0.12, -v.width * k * 0.35, v.length * k * 0.2, v.width * k * 0.7),
        glass,
      );
      canvas.restore();
    }
  }

  void _drawPreview(Canvas canvas) {
    if (tool == Tool.grid && stage == 1) {
      for (final p in gridPlans) {
        final good = p.error == null || p.error == "Mablag' yetarli emas";
        canvas.drawPath(
          _pathOf(p.pts),
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = RoadNetwork.roadWidth
            ..strokeCap = StrokeCap.round
            ..color = good ? const Color(0x8829C5D6) : const Color(0x66E0524A),
        );
      }
    }
    final plan = currentPlan;
    if (plan == null) return;
    final color = plan.valid ? const Color(0xAA29C5D6) : const Color(0xAAE0524A);
    canvas.drawPath(
      _pathOf(plan.pts),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = RoadNetwork.roadWidth
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..color = color,
    );
    final dot = Paint()..color = const Color(0xFF1B8FA0);
    canvas.drawCircle(plan.a, 5, dot);
    canvas.drawCircle(plan.b, 5, dot);
    if (plan.c != null && stage >= 2) {
      canvas.drawCircle(plan.c!, 6, Paint()..color = const Color(0xFFF2A33A));
    }
    // barmoqning haqiqiy joyi (to'q sariq halqa) va avtomatik ulangan nuqta orasidagi chiziq
    final ds = _dragScreen;
    if (ds != null && (stage == 1 || stage == 3)) {
      final raw = toWorld(ds);
      final target = stage == 1 ? _b : _c;
      canvas.drawCircle(
        raw,
        10 / zoom,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2 / zoom
          ..color = const Color(0xFFF2A33A),
      );
      if (target != null && (target - raw).distance > 4 / zoom) {
        canvas.drawLine(
          raw,
          target,
          Paint()
            ..strokeWidth = 1.5 / zoom
            ..color = const Color(0x99F2A33A),
        );
      }
    }
  }
}
