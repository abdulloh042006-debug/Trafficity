# Trafficity — Uzbekistan-Wide Multi-Region 2D/3D Expansion

Ushbu ZIP arxivda **Trafficity** loyihasining butun Oʻzbekiston (14 ta maʼmuriy hudud) boʻylab kengaytirilgan barcha fayllari jamlangan.

## Ishga tushirish va GitHub-ga Push Qilish

1. Ushbu `Trafficity-Uzbekistan-Complete.zip` arxivini loyiha papkangizga oching (extract qiling).
2. Terminalda quyidagi buyruqni bering:
   ```bash
   python3 tools/setup_and_push_github.py --push
   ```
